# VisionStudio

VisionStudio is an AI-powered design tool that revolutionizes the way you create and edit visual content.

## Deployment

To deploy VisionStudio:

1. Ensure you have a Vercel account and the Vercel CLI installed.

2. Set up your environment variables in Vercel:
   - Go to your Vercel dashboard
   - Navigate to your project settings
   - Add the environment variables as defined in `.env.local`

3. Deploy to Vercel:

